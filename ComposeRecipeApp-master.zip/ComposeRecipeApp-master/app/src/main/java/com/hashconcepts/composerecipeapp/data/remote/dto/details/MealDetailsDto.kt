package com.hashconcepts.composerecipeapp.data.remote.dto.details

data class MealDetailsDto(
    val meals: List<MealDto>
)