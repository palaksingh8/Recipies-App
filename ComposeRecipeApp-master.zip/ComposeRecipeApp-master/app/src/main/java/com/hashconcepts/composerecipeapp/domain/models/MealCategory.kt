package com.hashconcepts.composerecipeapp.domain.models

data class MealCategory(
    val idMeal: String,
    val strMeal: String,
    val strMealThumb: String
)