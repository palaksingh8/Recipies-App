package com.hashconcepts.composerecipeapp.data.remote.dto.mealByCategory

data class MealByCategoryDto(
    val meals: List<MealDto>
)