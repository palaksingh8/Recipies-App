package com.hashconcepts.composerecipeapp.data.remote.dto.category

data class MealCategoriesDto(
    val categories: List<CategoryDto>
)